def write_result(score, output):
    with open('/autograder/results/results.json', 'w') as f:
        f.write('{"score": %0.4f, "output": "%s"}' % (score, output))

def grade():
    write_result(0, "This is a temporary autograder. If you are a student seeing this, please post on Ed and tell course staff that this autograder hasn't been configured yet.")

if __name__ == '__main__':
    grade()
