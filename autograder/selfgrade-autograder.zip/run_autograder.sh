#!/usr/bin/env bash

# Set up autograder files

cd /autograder/source

python3 run_autograder.py
